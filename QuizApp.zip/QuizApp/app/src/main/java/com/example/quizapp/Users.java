package com.example.quizapp;

public class Users {


    String UserEmail, userName, password;

    public Users(String userName, String UserEmail, String password) {

        this.userName = userName;
        this.UserEmail = UserEmail;
        this.password = password;


    }

    public String getMail() {
        return UserEmail;
    }

    public void setMail(String mail) {
        this.UserEmail = mail;
    }
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}


